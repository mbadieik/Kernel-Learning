

function [NIPS2016]=Sinha_Gaussian(x_t,y_t,x_test,z_test,D,Nw,rho,tol,percent,lambda,sigma,ITER)


nips2016_error=zeros(3,length(D));
nips2016_train=zeros(1,length(D));
nips2016_test=zeros(1,length(D));
nips2016_process_time=zeros(1,length(D));

N=size(x_t,2);
L=ceil(N*percent/100);


for z=1:length(D)
    
    nips2016_train_t=zeros(1,ITER);
    nips2016_test_t=zeros(1,ITER);
    nips2016_error_t=zeros(2,ITER);
    nips2016_process_time_t=zeros(1,ITER);
    
    for iter=1:ITER
        
        tic;
        
        [Wopt, bopt, ~ , alpha_distrib] = optimizeGaussianKernel(x_t(:,1:L), y_t(1:L)'-mean(y_t(1:L)), Nw, rho, tol, sigma);
        
        nips2016_process_time_t(iter)=toc;
        
        tic;
        
        [D_opt, W_opt, b_opt] = createOptimizedGaussianKernelParams(D(z), Wopt, bopt, alpha_distrib);
        
        Z_opt_train = createRandomFourierFeaturesGaussian(D_opt, W_opt, b_opt, x_t);
        
        Mdl=fitclinear(Z_opt_train',y_t','Learner','logistic','Regularization','ridge','Lambda',lambda);
        
        nips2016_train_t(iter)=toc;
        
        tic;
        
        Z_opt_test = createRandomFourierFeaturesGaussian(D_opt, W_opt, b_opt, x_test);
        
        y_test=predict(Mdl,Z_opt_test');
        
        nips2016_test_t(iter)=toc;
        
        L_in=loss(Mdl,Z_opt_train',y_t');
        
        L_out=loss(Mdl,Z_opt_test',z_test');
        
        nips2016_error_t(1,iter)=L_in;
        nips2016_error_t(2,iter)=L_out;
        
    end
    
    
    nips2016_train(z)=mean(nips2016_train_t);
    nips2016_test(z)=mean(nips2016_test_t);
    nips2016_process_time(z)=mean(nips2016_process_time_t);
    
    nips2016_error(1,z)=mean(nips2016_error_t(1,:));
    nips2016_error(2,z)=mean(nips2016_error_t(2,:));
    nips2016_error(3,z)=std(nips2016_error_t(2,:))/sqrt(ITER);
    
end

NIPS2016=[nips2016_error ; nips2016_process_time ; nips2016_train ; nips2016_test];


end