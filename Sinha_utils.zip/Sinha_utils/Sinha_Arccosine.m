

function [NIPS2016,process_time]=Sinha_Arccosine(x_t,y_t,x_test,z_test,D,Nw,rho,tol,lambda,order,ITER)

process_time=[];

nips2016_error=zeros(2,length(D));
nips2016_train=zeros(1,length(D));
nips2016_test=zeros(1,length(D));

tic;

[Wopt, ~ , alpha_distrib] = optimizeArccosineKernel(x_t, y_t', Nw, rho, tol, order);

process_time(end+1)=toc;

for z=1:length(D)
    
    clear nips2016_train_t;
    clear nips2016_test_t;
    
    nips2016_train_t=[];
    nips2016_test_t=[];
    
    for iter=1:ITER
                
        tic;
        
        [D_opt, W_opt] = createOptimizedArccosineKernelParams(D(z), Wopt, alpha_distrib);
        
        Z_opt_train = createRandomFourierFeaturesArccosine(D_opt, W_opt, x_t,order);
        
        Mdl=fitclinear(Z_opt_train',y_t','Learner','svm','Regularization','ridge','Lambda',lambda);
        
        nips2016_train_t(end+1)=toc;
        
        tic;
        
        Z_opt_test = createRandomFourierFeaturesArccosine(D_opt, W_opt, x_test,order);
        
        y_test=predict(Mdl,Z_opt_test');
        
        nips2016_test_t(end+1)=toc;
        
        L_in=loss(Mdl,Z_opt_train',y_t');
        
        L_out=loss(Mdl,Z_opt_test',z_test');
        
        nips2016_error(1,z)=nips2016_error(1,z)+L_in;
        nips2016_error(2,z)=nips2016_error(2,z)+L_out;
        
    end
    
    nips2016_train(z)=mean(nips2016_train_t);
    nips2016_test(z)=mean(nips2016_test_t);
    
end

NIPS2016=[nips2016_error/ITER ; nips2016_train ; nips2016_test];


end