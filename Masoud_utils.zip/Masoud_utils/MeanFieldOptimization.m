function [Wopt_1,bopt_1,t] = MeanFieldOptimization(X,Y,d,D) 
i=1;
tic
xi=randn(d,D);


b1 = rand(1,D)*2*pi;
T=15000; %Number of Iteration
eta=10;
beta=1;

while i<=T

    
dr1=round((length(X)-1)*rand)+1;
dr2=round((length(X)-1)*rand)+1;

Phi1=(1/sqrt(D))*cos(X(:,dr1)'*xi+b1);
Phi2=(1/sqrt(D))*cos(X(:,dr2)'*xi+b1);

Psi1=(1/sqrt(D))*sin(X(:,dr1)'*xi+b1);
Psi2=(1/sqrt(D))*sin(X(:,dr2)'*xi+b1);

xi=xi-eta*((beta*Y(dr1)*Y(dr2)-((1/D)*Phi1*Phi2')).*(X(:,dr1)*(Psi1.*Phi2)+X(:,dr2)*(Psi2.*Phi1)));   
i=i+1;
end
toc;
t = toc;
% Score=zeros(1,D);
% for i=1:D 
%     Score(1,i)=sum(Y'*cos(X'*xi(:,i)+b1(i)));
% end
% Highest_Score=flip(sort(Score));
% Score_Subset=Highest_Score(1:363);
% [~, pos] = ismember(Score_Subset,Score);


Wopt_1=xi;
%Wopt_1_subset=xi(:,pos);
bopt_1=b1;
%bopt_subset_1=b1(pos);

end



