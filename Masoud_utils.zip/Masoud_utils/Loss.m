function [error] = Loss(Z, w, meany, y)
    y_predict=(w'*Z)+meany;
    error=(1/length(y))*sum((y_predict'-y).^2);
end