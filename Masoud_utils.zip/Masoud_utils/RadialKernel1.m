function [Wopt_2,bopt_2,t] = RadialKernel1(xxx,yyy,d,D) 
i=1;
tic

N=D;
NL=length(yyy);
zeta=max(0,randn(N,1));
epsilon=1;
xi=zeta;
eta=.00001;
beta=1;
T=100000; %Number of Iteration
for k=1:T
dr1=round((NL-1)*rand)+1;
dr2=round((NL-1)*rand)+1;
P=norm(xxx(:,dr1)-xxx(:,dr2),2);
xi=max(0,xi+eta*(yyy(dr1)*yyy(dr2)*(1/N).*P*exp(-xi.*P)));
end

toc;
t=toc;

mu=zeros(N,d);
Sigma1=zeros(d,d,N);
for i=1:N
    Sigma1(:,:,i)=xi(i)*eye(d,d);
end

gm = gmdistribution(mu,Sigma1);
Wopt_2=transpose(random(gm,D));
bopt_2=rand(1,D)*2*pi;


end



