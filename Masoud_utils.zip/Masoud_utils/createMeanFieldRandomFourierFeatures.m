function Z = MeanFieldOptimization(X,y,d,D) 
i=1;
%autoenc = trainAutoencoder(x_train,D,'SparsityRegularization',0)
xi=randn(d,D);
T=10000; %Number of Iteration


NL=length(X)
while i<=T
i
%y=-1+2*round(rand(1,2));
dr1=round((NL-1)*rand)+1;
dr2=round((NL-1)*rand)+1;

b1=2*pi*rand(1,D);
b2=2*pi*rand(1,D);
%x1=(1/2)*(1+y(1))*((1+dlambda)^.5)*Sigma*randn(d,1)-(1/2)*(-1+y(1))*((1-lambda)^.5)*Sigma*randn(d,1);
%x2=(1/2)*(1+y(2))*((1+lambda)^.5)*Sigma*randn(d,1)-(1/2)*(-1+y(2))*((1-lambda)^.5)*Sigma*randn(d,1);
Phi1=cos(X(:,dr1)'*xi+b1);
Phi2=cos(X(:,dr2)'*xi+b2);

Psi1=sin(X(:,dr1)'*xi+b1);
Psi2=sin(X(:,dr2)'*xi+b2);

xi=xi-eta*((beta*yyy(dr1)*yyy(dr2)-((1/D)*Phi1*Phi2')).*(xxx(:,dr1)*(Phi1.*Phi2)+xxx(:,dr2)*(Phi2.*Phi1)));   
end
i=i+1;

Z=xi;

end



