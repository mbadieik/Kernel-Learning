function [Wopt_2,bopt_2,t] = RadialKernel(xxx,yyy,d,D) 
i=1;
tic

N=D;
NL=length(yyy);
NL=length(yyy);
zeta=max(0,randn(N,1));
epsilon=1;
xi=zeta;
eta=.00001;
R=10;
beta=100000;
h_u=Inf; h_l=0; h_s=1;
[Distance,Diff,K,u,v]= WD(xi,zeta,epsilon);  

while h_u==Inf 
for k=1:1
dr1=round((NL-1)*rand)+1;
dr2=round((NL-1)*rand)+1;
P=norm(xxx(:,dr1)-xxx(:,dr2),2);
Term1=-((beta*yyy(dr1)*yyy(dr2)-(1/N)*sum(exp(-xi.*P))).*P*exp(-xi.*P));
Term2=(h_s/2)*(u.*(K.*((Diff.^3./epsilon)-Diff)*v));
xi=max(0,xi-eta*(Term1+Term2));
end
[Distance,Diff,K,u,v]= WD(xi,zeta,epsilon);  
Distance
if Distance<R
    h_u=h_s;
    'success'
else
    h_s=2*h_s;
end   
end

while h_u-h_l>.1
h_s=(h_u+h_l)/2 
h_l
h_u
for k=1:10
dr1=round((NL-1)*rand)+1;
dr2=round((NL-1)*rand)+1;
P=norm(xxx(:,dr1)-xxx(:,dr2),2);
Term1=((beta*yyy(dr1)*yyy(dr2)-(1/N)*sum(exp(-xi.*P))).*P*exp(-xi.*P));
Term2=(h_s/2)*(u.*(K.*((Diff.^3./epsilon)-Diff)*v));
xi=max(0,xi-eta*(Term1+Term2));   
end
[Distance,Diff,K,u,v]= WD(xi,zeta,epsilon);  
if Distance<R
    h_u=h_s;
else
    h_l=h_s;
end  
end
toc;
t=toc;

mu=zeros(N,d);
Sigma1=zeros(d,d,N);
for i=1:N
    Sigma1(:,:,i)=xi(i)*eye(d,d);
end

gm = gmdistribution(mu,Sigma1);
Wopt_2=transpose(random(gm,D));
bopt_2=rand(1,D)*2*pi;
end



