clc
YY = tsne(Z_train','Algorithm','barneshut','NumPCAComponents',50,'NumDimensions',3,'Perplexity',100);
YY_SGD = tsne(Z_opt_1_train','Algorithm','barneshut','NumPCAComponents',50,'NumDimensions',3,'Perplexity',100);
YY_IS = tsne(Z_opt_train','Algorithm','barneshut','NumPCAComponents',50,'NumDimensions',3,'Perplexity',100);

figure(1)
scatter3(YY(:,1),YY(:,2),YY(:,3),40,ytrain,'filled','MarkerEdgeColor','k'), hold on
view(-10,14)

figure(2)
scatter3(YY_SGD(:,1),YY_SGD(:,2),YY_SGD(:,3),40,ytrain,'filled','MarkerEdgeColor','k'), hold on
view(-10,14)
 figure(3)
scatter3(YY_IS(:,1),YY_IS(:,2),YY_IS(:,3),40, ytrain,'filled','MarkerEdgeColor','k'), hold on
view(-10,14)