function D2 = leedist(XI,XJ) 




end