clc
clear all
global d Sigma beta lambda
d=3;
Sigma=eye(d,d);
N=100;
eta=.1;
lambda=.9;
beta=1;
xi=-2000*rand(d,N)+1000;
T=5000;
i=1;
n=1000; 
kk=1;
list=1:10:T;
set(gca,'visible','off')
NL=5000;


yyy=-1+2*round(rand(1,NL));
for i=1:NL
    if yyy(i)==1
        xxx(i,:)=((1+lambda)^.5)*Sigma*randn(d,1);
    else
        xxx(i,:)=((1-lambda)^.5)*Sigma*randn(d,1);
    end
end

Plus=find(yyy==-1);
Minus=find(yyy==+1);

scatter3(xxx(Minus,1),xxx(Minus,2),xxx(Minus,3),...
        'MarkerEdgeColor','k',...
        'MarkerFaceColor',[0 .75 .75]), hold on
    
scatter3(xxx(Plus,1),xxx(Plus,2),xxx(Plus,3),...
        'MarkerEdgeColor','r',...
        'MarkerFaceColor',[.1 .5  .1])
view(-30,10)



%plot(xxx(Minus,1),xxx(Minus,2),xxx(Minus,3),'r+'), hold on
%plot(xxx(Plus,1),xxx(Plus,2),xxx(Plus,3),'+'), hold on
