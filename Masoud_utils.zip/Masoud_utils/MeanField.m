function Z = MeanField(X,y,d,D) 
i=1;
%autoenc = trainAutoencoder(x_train,D,'SparsityRegularization',0)
zeta=100*rand(1,D);
epsilon=0.001;
R=1;
xi=zeta;
NL=length(y);
h_u=Inf; h_l=0; h_s=1;
[Distance,u,v,K,Diff]= WD(xi,zeta,epsilon);  
while h_u==Inf   
dr1=round((NL-1)*rand)+1;
dr2=round((NL-1)*rand)+1;
P=norm(X(:,dr1)-X(:,dr2),2);
Term1=((beta*yyy(dr1)*yyy(dr2)-(1/D)*sum(exp(-xi.*P))).*P*exp(-xi.*P));
Term2=(h_s/2)*(u.*(K.*((Diff.^3./epsilon) -Diff)*v));
xi=max(0,xi-eta*(Term1+Term2));    
[Distance,u,v,K,Diff]= WD(xi,zeta,epsilon);  
if Distance<R
    h_u=h_s;
else
    h_s=2*h_s;
end   
end

while h_u-h_l>.001
h_s=(h_u+h_l)/2;       
dr1=round((NL-1)*rand)+1;
dr2=round((NL-1)*rand)+1;
P=norm(X(:,dr1)-X(:,dr2),2);
Term1=((beta*yyy(dr1)*yyy(dr2)-(1/D)*sum(exp(-xi.*P))).*P*exp(-xi.*P));
Term2=(h_s/2)*(u.*(K.*((Diff.^3./epsilon) -Diff)*v));
xi=max(0,xi-eta*(Term1+Term2));     
[Distance,u,v,K,Diff]= WD(xi,zeta,epsilon);  
if Distance<R
    h_u=h_s;
else
    h_l=h_s;
end   
end

end






